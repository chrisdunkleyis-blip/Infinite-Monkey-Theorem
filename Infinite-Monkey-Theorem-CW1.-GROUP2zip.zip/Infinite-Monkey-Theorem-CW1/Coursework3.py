import random as rd
import matplotlib.pyplot as plt
import Coursework_Funs as fnc


#Task 3

#take a random_sentence and analyse how the mutation rate effects the runs needed to obtain our DESIRED_SENTENCE

random_sentence = fnc.genRANDText()
for i in range(1, len(random_sentence) + 1):
    scores_random_sentence = []
    evo = random_sentence
    for j in range(9000):
        evo = fnc.evolution(evo, i)
        scores_random_sentence.append(fnc.score(evo))
    plt.bar(i, scores_random_sentence[-1])
plt.title("How mutation rate effects the score after 9000 loops")
plt.xlabel("Mutation rate")
plt.ylabel("Score after loops")
plt.show()


#2
#Idea is to reward the variations with another 'score' the closer the i-th letter is to the desired i-th letter. 
#The reason for this is because evolution is driven by natural selection, and not rewarding an animal when they have a close trait
# to the one desired is false.
#So if we were rewarding, we would do it like so:
# example random_sentence:
#              "duqehfg dhquex"
#Target sentence:
#              "two is a prime"
#for our first letter 'd' in random_sentence, we will want to obtain somwthing in theory 'closer' to the desired letter, 't' and 
# then reward the string with a lower difference based on how close the mutated characters are to the desired one. A difference
# of 0 implies the sentence is now equal to the desired sentence.


#showcases 50 different random_sentences' closeness_score on a bar chart
ls = []

for i in range(50):
    sentence = fnc.genRANDText()
    ls.append(fnc.closeness(sentence))
    plt.bar(i, ls[-1])
print("Average score: ", sum(ls) / len(ls))
print("Best score: ", max(ls))
print("Worst score: ", min(ls))
plt.title("Closeness of random_sentence")
plt.xlabel("random_sentence")
plt.ylabel("Average Closeness")
plt.show()


#Now will take into account evolution and how mutation rate changes the closeness_score of a random_sentence

random_sentence = fnc.genRANDText()
for i in range(1, len(random_sentence) + 1):
    new_score_rand = []
    evo = random_sentence
    for j in range(5000):
        evo = fnc.evolution(evo, i)
        new_score_rand.append(fnc.closeness(evo))
    plt.bar(i, new_score_rand[-1])
    
plt.title("Closeness of the string")
plt.xlabel("Mutation rate")
plt.ylabel("Average closeness")
plt.show()

# Now with this we can apply the theory of a selection pressure further. Lets say we have 50 different strings (characters),
# See if mutation rate alters average closeness differently to previous evolution across iterations and with which rate
# does it actually optimise evolution.

# Using our function defined by average_evolution(), we will see how mutation rate will effect the closeness of a random sentence,
# and see what the outcome is...


rand = fnc.genRANDText()
ls = []
for i in range(9000):
    rand = fnc.average_evolution(rand, 1)
    ls.append(fnc.closeness(rand))
print(ls[-1])


#comparing relationship with score and closeness across 10000 evolutions for a single sentence.
sentence = fnc.genRANDText()
scores = []
close = []
for i in range(10000):
    sentence = fnc.average_evolution(sentence, 1)
    scores.append(fnc.score(sentence))
    close.append(fnc.closeness(sentence))
    plt.plot(close)
    plt.plot(scores)
plt.xlabel("Generations")
plt.ylabel("Score/Closeness")
plt.title("How a sentence's score and closeness change with evolutions")
plt.show()
